package br.com.avf.services.discoveryservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscoveryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
