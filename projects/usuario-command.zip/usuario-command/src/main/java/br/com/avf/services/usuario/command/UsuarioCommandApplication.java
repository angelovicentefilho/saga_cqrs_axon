package br.com.avf.services.usuario.command;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsuarioCommandApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsuarioCommandApplication.class, args);
	}

}
