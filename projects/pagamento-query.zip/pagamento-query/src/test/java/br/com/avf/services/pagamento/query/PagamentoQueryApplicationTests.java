package br.com.avf.services.pagamento.query;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PagamentoQueryApplicationTests {

	@Test
	void contextLoads() {
	}

}
