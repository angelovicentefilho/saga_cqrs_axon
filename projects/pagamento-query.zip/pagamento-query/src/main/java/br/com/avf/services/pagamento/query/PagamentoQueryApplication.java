package br.com.avf.services.pagamento.query;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PagamentoQueryApplication {

	public static void main(String[] args) {
		SpringApplication.run(PagamentoQueryApplication.class, args);
	}

}
