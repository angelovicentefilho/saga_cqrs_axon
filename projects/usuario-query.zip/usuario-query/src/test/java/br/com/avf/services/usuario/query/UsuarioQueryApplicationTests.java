package br.com.avf.services.usuario.query;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsuarioQueryApplicationTests {

	@Test
	void contextLoads() {
	}

}
