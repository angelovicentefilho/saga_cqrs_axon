package br.com.avf.services.pedido.command;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PedidoCommandApplicationTests {

	@Test
	void contextLoads() {
	}

}
