package br.com.avf.services.pedido.command;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PedidoCommandApplication {

	public static void main(String[] args) {
		SpringApplication.run(PedidoCommandApplication.class, args);
	}

}
