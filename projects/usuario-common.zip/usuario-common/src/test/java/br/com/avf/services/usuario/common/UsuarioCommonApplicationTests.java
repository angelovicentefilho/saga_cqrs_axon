package br.com.avf.services.usuario.common;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsuarioCommonApplicationTests {

	@Test
	void contextLoads() {
	}

}
