package br.com.avf.services.usuario.oauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsuarioOauthApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsuarioOauthApplication.class, args);
	}

}
