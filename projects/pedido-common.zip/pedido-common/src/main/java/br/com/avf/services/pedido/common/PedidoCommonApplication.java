package br.com.avf.services.pedido.common;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PedidoCommonApplication {

	public static void main(String[] args) {
		SpringApplication.run(PedidoCommonApplication.class, args);
	}

}
