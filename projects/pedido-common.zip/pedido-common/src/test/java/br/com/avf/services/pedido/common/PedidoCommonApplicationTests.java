package br.com.avf.services.pedido.common;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PedidoCommonApplicationTests {

	@Test
	void contextLoads() {
	}

}
