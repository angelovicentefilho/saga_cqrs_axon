package br.com.avf.services.envio.common;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnvioCommonApplicationTests {

	@Test
	void contextLoads() {
	}

}
