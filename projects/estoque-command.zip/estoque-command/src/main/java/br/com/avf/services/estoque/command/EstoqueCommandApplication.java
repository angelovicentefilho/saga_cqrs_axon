package br.com.avf.services.estoque.command;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EstoqueCommandApplication {

	public static void main(String[] args) {
		SpringApplication.run(EstoqueCommandApplication.class, args);
	}

}
