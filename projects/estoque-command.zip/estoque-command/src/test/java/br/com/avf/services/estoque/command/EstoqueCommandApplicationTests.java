package br.com.avf.services.estoque.command;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstoqueCommandApplicationTests {

	@Test
	void contextLoads() {
	}

}
