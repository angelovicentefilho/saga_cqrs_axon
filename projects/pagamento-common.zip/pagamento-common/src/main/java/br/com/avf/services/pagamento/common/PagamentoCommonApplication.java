package br.com.avf.services.pagamento.common;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PagamentoCommonApplication {

	public static void main(String[] args) {
		SpringApplication.run(PagamentoCommonApplication.class, args);
	}

}
