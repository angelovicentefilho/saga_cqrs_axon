package br.com.avf.services.pagamento.common;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PagamentoCommonApplicationTests {

	@Test
	void contextLoads() {
	}

}
