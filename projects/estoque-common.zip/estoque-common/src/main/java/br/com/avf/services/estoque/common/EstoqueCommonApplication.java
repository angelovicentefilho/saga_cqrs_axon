package br.com.avf.services.estoque.common;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EstoqueCommonApplication {

	public static void main(String[] args) {
		SpringApplication.run(EstoqueCommonApplication.class, args);
	}

}
