package br.com.avf.services.estoque.common;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstoqueCommonApplicationTests {

	@Test
	void contextLoads() {
	}

}
