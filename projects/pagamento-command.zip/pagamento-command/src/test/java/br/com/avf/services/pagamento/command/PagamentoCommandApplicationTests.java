package br.com.avf.services.pagamento.command;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PagamentoCommandApplicationTests {

	@Test
	void contextLoads() {
	}

}
