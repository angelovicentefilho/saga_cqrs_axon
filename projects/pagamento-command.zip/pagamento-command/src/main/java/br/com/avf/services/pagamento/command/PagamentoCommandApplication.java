package br.com.avf.services.pagamento.command;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PagamentoCommandApplication {

	public static void main(String[] args) {
		SpringApplication.run(PagamentoCommandApplication.class, args);
	}

}
